package com.avdotline.avlink;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/*
 * Created by Akshay on 08-Jan-19.
 */
public class MainActivity extends AppCompatActivity {

    private String myStrUrl = "";
    private String myWebInterfaceName = null;
    private EditText myEditTextAddUrl;
    private Button mySearchGo;
    private WebView myWebViewMainActivity;
    private String myOrientationType;
    private Activity myActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CommonUtils.setCommonVariables(MainActivity.this);
        CommonUtils.closeOnCrashApp(MainActivity.this);

        initialiseAllControls();

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            //myOrientationType = bundle.getString(CommonUtils.INTENT_ORIENTATION_TYPE);
        }
        if (myOrientationType != null) {
            if (myOrientationType.equalsIgnoreCase(CommonUtils.STRING_LANDSCAPE)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        }

        myWebViewMainActivity.clearCache(true);
        myWebViewMainActivity.clearHistory();
        myWebViewMainActivity.clearFormData();
        myWebViewMainActivity.setBackgroundColor(getResources().getColor(R.color.white));
        WebSettings webSettings = myWebViewMainActivity.getSettings();
        // To enable java script on page.
        webSettings.setJavaScriptEnabled(true);


        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setBuiltInZoomControls(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            webSettings.setMediaPlaybackRequiresUserGesture(false);
        }

        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);


        int currentapiVersion = Build.VERSION.SDK_INT;
        if (currentapiVersion >= Build.VERSION_CODES.JELLY_BEAN) {
            fixNewAndroid(myWebViewMainActivity);
        }

        myWebViewMainActivity.setWebChromeClient(new WebChromeClient(){

        });

        myWebViewMainActivity.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                myEditTextAddUrl.setText(url);
            }

            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                myEditTextAddUrl.setText(url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }

        });

        myStrUrl = "https://www.google.co.in";
        myEditTextAddUrl.setText(myStrUrl);
        if (CommonUtils.isConnected(this)) {
            myWebViewMainActivity.loadUrl(myStrUrl);
        } else {
            closeAppOnWebViewError("004 - Error: \nNo Network Connection available.");
        }


    }


    @Override
    public void onBackPressed() {
        myWebViewMainActivity.goBack();
        //super.onBackPressed();
        myEditTextAddUrl.setText(myStrUrl);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    private void initialiseAllControls(){
        myEditTextAddUrl = findViewById(R.id.editTextAddUrl);
        mySearchGo = findViewById(R.id.buttonSearchGo);
        mySearchGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(CommonUtils.isConnected(MainActivity.this)) {
                    goToSite();
                } else {
                    CommonUtils.showAlertDialogWithFinishActivity(MainActivity.this, "Please Check your network or Wifi connection.", CommonUtils.APP_NAME, false,  Activity.RESULT_OK, null);
                }
            }
        });
        myWebViewMainActivity = findViewById(R.id.webViewMainActivity);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    protected void fixNewAndroid(WebView webView) {
        try {
            webView.getSettings().setAllowUniversalAccessFromFileURLs(true);
        } catch (NullPointerException e) {
        }
    }

    private void goToSite(){
        myStrUrl = myEditTextAddUrl.getText().toString();
        if (myStrUrl.contains("http://")){
            myWebViewMainActivity.loadUrl(myStrUrl);
        } else {
            myWebViewMainActivity.loadUrl("http://" + myStrUrl);
        }
    }

    public void closeAppOnWebViewError(String theErrorMessage) {
        Intent intent = new Intent();
        intent.putExtra(CommonUtils.INTENT_AUTO_CLOSE_APP, true);
        CommonUtils.showAlertDialogWithFinishActivity(MainActivity.this,
                theErrorMessage, "AVLink", true,
                Activity.RESULT_OK, intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    if (resultCode == CommonUtils.RESULT_OK){


    }

        }

}
