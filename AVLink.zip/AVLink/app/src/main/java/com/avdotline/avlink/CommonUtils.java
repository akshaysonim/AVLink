package com.avdotline.avlink;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.graphics.Color.BLACK;
import static android.graphics.Color.WHITE;
/*
 * Created by Akshay on 09-Jan-19.
 */

public class CommonUtils{

    // General
    public static final String APP_NAME = "AVLink";
    public static final String ASSETS_DATA_FOLDER_NAME = "Data";
    public static final String TEMP_FOLDER_NAME = "Temp";
    public static final String STRING_FORMAT_PDF_FILE = "yyyyMMddHHmmss";
    public static int ALERT_DAILOG_THEME;
    private static final String PROVIDER_FILE_EXTENSION = ".provider";
    private static final int ERROR_LIST_01 = 01;
    private static final int ERROR_LIST_02 = 02;
    public static final String INTENT_AUTO_CLOSE_APP = "AutoCloseApp";

    // Intent
    public static final String INTENT_PAGE_NO = "PageNo";
    public static final String INTENT_FILE_PATH = "FilePath";

    // Extension
    public static final String JPG_EXTENSION = ".jpg";
    public static final String PNG_EXTENSION = ".png";
    public static final String MP4_EXTENSION = ".mp4";

    public static final String JSON_FILE_EXTENSION = ".json";
    public static final String E_DATA_JSON_FILENAME = "Data.json";
    public static final String E_EMAIL_ID = "Email_Id";
    public static final String E_HTTP_BASE_PATH = "BasePath";
    public static final String E_TUTORIAL_DOWNLOAD_URL = "DownloadUrl";
    public static final String E_FILES_JSON_ARRAY_NAME = "Files";
    public static final String E_FILE_NAME = "FileName";

    //Preference key
    public static final String VERSION_PREFERENCE_CODE = "version_code";
    public static final String VIEW_CLICK_TAG = "Tag";
    public static final String ID = "Id";

    // Other String
    public static final String STRING_POTRAIT = "portrait";
    public static final String STRING_LANDSCAPE = "landscape";
    public static final String STRING_TRUE = "true";
    public static final String STRING_FALSE = "false";
    public static final int VALUE_TRUE = 1;
    public static final int VALUE_FALSE = 0;
    public static final int RESULT_OK = 1;

    //public static final String WEB_SERVICE_BASE_PATH = "https://";

    //activty request code
    public static final int NO_RESULT = -5;
    public static final int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 100;
    public static String MId = "";
    public static String AppFolderName = "";
    public static String AlertTitle = "";
    public static String PreferenceFileName = "AVLinkPreference.xml";
    public static String SDCardBasePath = "";

    public static void createExDirectory(String theFolderName, Context theContext, String thePathToExternalStorage) {
        String returnPath = "";
        boolean success;

        Boolean isSDPresent = Environment.getExternalStorageState()
                .equals(Environment.MEDIA_MOUNTED);

        if (isSDPresent) {
            // yes SD-card is present
            //String pathToExternalStorage = Environment.getExternalStorageDirectory().toString();

            File appDirectory = new File(thePathToExternalStorage + "/" + theFolderName);
            // have the object build the directory structure, if needed.

            success = appDirectory.exists() || appDirectory.mkdirs();
            //Creating Directory to external storage

            if (success) {
                returnPath = appDirectory.getAbsolutePath();
                Log.v("returnPath", returnPath);
            }
        }

        //  return returnPath;
    }

    public static void createRequiredFolders(Context ctx, String theAppFolderName) {

        //createExDirectory(PDF_IMAGE_FOLDER_NAME, ctx, theAppFolderName + "/" + AppFolderName + "/" + TEMP_FOLDER_NAME);
    }

    public static ArrayList<String> listFilesFromSDCardWithFileFilter(String path, String theFilter, boolean theIsFullPath) {
        ArrayList<String> arrayListFolders = new ArrayList<>();

        try {
            File[] dir = new File(path).listFiles();

            if (null != dir && dir.length > 0) {
                for (int i = 0; i < dir.length; i++) {
                    if (!dir[i].isDirectory()) {
                        if (!theFilter.isEmpty() && dir[i].toString().endsWith(theFilter)) {
                            if (theIsFullPath) {
                                arrayListFolders.add(new File(dir[i].toString()).getAbsolutePath());
                            } else {
                                arrayListFolders.add(new File(dir[i].toString()).getName());
                            }

                        }

                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return arrayListFolders;
    }


    public static ArrayList<String> changeExtension(ArrayList<String> theArrayList, String theExisting, String theReplace) {
        ArrayList<String> arrayListFolders = new ArrayList<>();

        for (String data : theArrayList) {
            String name = data.replace(theExisting, theReplace);

            arrayListFolders.add(name);
        }

        return arrayListFolders;
    }



    public static void setCommonVariables(Context context) {


        String root_sd = Environment.getExternalStorageDirectory().toString();

        SDCardBasePath = root_sd + "/" + AppFolderName;

        //code for getting IMEI number
        // for getting the last fpur digit of IMEI number
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        String IMEI_Number = telephonyManager.getDeviceId();
        String address = null;
        WifiManager manager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = manager.getConnectionInfo();
        // if (registrationServiceNo.equals(REGISTRATION_SERVICE_NO)) {
        if (IMEI_Number == null || IMEI_Number.isEmpty() || IMEI_Number.equals("000000000000000")) {
            address = info.getMacAddress();
        }

        String deviceId = "";
        if ((null == IMEI_Number || IMEI_Number.equals("000000000000000"))
                && null != address && (!address.equals("02:00:00:00:00:00"))) {
            deviceId = "(" + address + ")";
        } else if (null != IMEI_Number && (!IMEI_Number.equals("000000000000000"))
                && (null == address || address.equals("02:00:00:00:00:00"))) {
            deviceId = IMEI_Number;
        } else {
            if ((IMEI_Number != null && (!IMEI_Number.equals("000000000000000")))
                    && (address != null && (!address.equals("02:00:00:00:00:00")))) {
                deviceId = IMEI_Number + "(" + address + ")";
            }
        }

        String deviceIdHash = "";
        if (deviceId.isEmpty()) {

        } else {
            try {
                deviceIdHash = SimpleSHA1.SHA1(deviceId);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }
        MId = deviceIdHash;

    }

    public static void showAlertDialogWithFinishActivity(final Context theContext, String theMessage, String theTitle, final boolean thefinish, final int theSetResult, final Intent data) {
        //		if (theContext == null) {
        //			theContext = ShootXpress.getContext();
        //			}
        // SS TODO  progress dialog theme color.
        new AlertDialog.Builder(theContext, ALERT_DAILOG_THEME).setTitle(theTitle).
                setMessage(theMessage).setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (thefinish) {
                    if (theSetResult != NO_RESULT) {
                        if (data == null) {
                            ((Activity) theContext).setResult(theSetResult);
                        } else {
                            ((Activity) theContext).setResult(theSetResult, data);
                        }

                    }
                    ((Activity) theContext).finish();
                }

            }
        }).setCancelable(false).create().show();
    }

    // To check if the user has put characters required fo valid email
    public static boolean ValidEmail(String email) {
        boolean ValidEmail = false;

        String emailExpression = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";

        Pattern pattern = Pattern.compile(emailExpression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        if (matcher.matches()) {
            ValidEmail = true;
        }
        return ValidEmail;
    }

    public static boolean isConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = null;
        if (cm != null) {
            activeNetwork = cm.getActiveNetworkInfo();
        }

        return activeNetwork != null && activeNetwork.isConnected();

    }

    /*public static void dialogContactUs(final Context ctx, String theMessage) {
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_contact_us);

        TextView textViewMsg = dialog.findViewById(R.id.textViewContactMsg);
        Button contactUs = dialog.findViewById(R.id.buttonContactUs);
        Button contactOurResellers = dialog.findViewById(R.id.buttonContactOurResellers);

        textViewMsg.setText(theMessage);
        contactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx, ContactActivity.class);
                ctx.startActivity(i);
                dialog.cancel();
            }
        });

        contactOurResellers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ctx, ContactActivity.class);
                ctx.startActivity(i);
                dialog.cancel();
            }
        });

        dialog.show();
    }*/

    public static String getStringFromJson(JSONObject userjsonobject, String mappedName, String existingString) {
        String rString = existingString;
        try {
            if (!userjsonobject.isNull(mappedName)) {
                rString = userjsonobject.getString(mappedName);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rString;
    }

    public static void putStringToJson(JSONObject userjsonobject, String mappedName, String data) {
        try {
            userjsonobject.put(mappedName, data);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        // return userjsonobject;
    }

    public static void copyFilefromAsset(AssetManager theAssetManager, String filename, String targetPath, String theLoadFolder) {
        //AssetManager assetManager = theContext.getAssets();

        InputStream in = null;
        OutputStream out = null;
        String newFileName = null;
        try {
            //Log.i(TAG, "copyFile() " + filename);
            in = theAssetManager.open(theLoadFolder + "/" + filename);
            out = new FileOutputStream(targetPath);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            in = null;
            out.flush();
            out.close();
            out = null;
        } catch (Exception e) {
            //Log.e(TAG, "Exception in copyFile() of " + newFileName);
            //Log.e(TAG, "Exception in copyFile() " + e.toString());
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                in = null;

            }
            if (out != null) {
                try {
                    out.flush();
                    out.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                out = null;
            }
            // return false;
        }
        // return true;
    }

    public static String readFileFromAssets(String theFilePathString, Activity theActivity) {
        String returnString = "";
        // To load text file

        try {
            InputStream is = theActivity.getAssets().open(theFilePathString);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF8"));
            String line = null;
            while ((line = br.readLine()) != null) {

                returnString = returnString + line;
            }
            br.close();

        } catch (IOException e) {

            e.printStackTrace();
        }
        return returnString;
    }

    public static String readFile(String theFilePathString) {
        String returnString = "";
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream((theFilePathString)), "UTF8"));
            String line = null;
            StringBuilder stringBuilder = new StringBuilder();
            String ls = System.getProperty("line.separator");

            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(ls);
            }
            reader.close();
            returnString = stringBuilder.toString();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return returnString;
    }

    public static Boolean downloadFile(String theSourcePath, String theTargetPath) {
        int count;
        InputStream input = null;
        OutputStream output = null;
        try {


            theSourcePath = encodeUrlString(theSourcePath);
            URL url = new URL(theSourcePath);
            URLConnection conexion = url.openConnection();
            conexion.connect();

            input = new BufferedInputStream(url.openStream());
            output = new FileOutputStream(theTargetPath);

            byte data[] = new byte[1024];

            long total = 0;

            while ((count = input.read(data)) != -1) {
                total += count;
                //publishProgress(""+(int)((total*100)/lenghtOfFile));
                output.write(data, 0, count);
            }

            output.flush();
            output.close();
            input.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (output != null) {
                    output.flush();
                    output.close();
                }
                if (input != null) {
                    input.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();

            }
            return false;
        }
    }

    public static String encodeUrlString(String theSrcUrl) {

        try {
            URL url = new URL(theSrcUrl);
            String context = url.getProtocol();
            String hostname = url.getHost();
            String thePath = url.getPath();
            thePath = thePath.replaceAll("(^/|/$)", ""); // removes beginning/end slash
            String encodedPath = URLEncoder.encode(thePath, "UTF-8"); // encodes unicode characters
            encodedPath = encodedPath.replace("+", "%20"); // change + to %20 (space)
            encodedPath = encodedPath.replace("%2F", "/"); // change %2F back to slash
            theSrcUrl = context + "://" + hostname + "/" + encodedPath;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return theSrcUrl;
    }

    public static ArrayList<String> listFoldersFromSDCard(String path) {
        ArrayList<String> arrayListFolders = new ArrayList<String>();

        try {
            File[] dir = new File(path).listFiles();

            if (null != dir && dir.length > 0) {
                for (int i = 0; i < dir.length; i++) {
                    if (dir[i].isDirectory()) {
                        arrayListFolders.add(new File(dir[i].toString()).getName());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return arrayListFolders;
    }
    public static int writeFileToSDCard(String theData, String thePath) {

        File f = new File(thePath);
        f.delete(); // old file will be deleted
        Writer out = null;
        try {
            f.createNewFile();
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF8"));
            //writing to file
            out.append(theData);  // all the data in PhotoPrintJsonObject will be appended to the file
            out.flush();
            out.close();
            return 0;

        } catch (IOException e) {
            //e.printStackTrace();
            try {

                out.flush();
                out.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            } catch (Exception ee) {
                ee.printStackTrace();
            }
            return ERROR_LIST_01;
        } catch (Exception e) {
            //e.printStackTrace();
            try {
                out.flush();
                out.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            } catch (Exception ee) {
                ee.printStackTrace();
            }
            return ERROR_LIST_02;
        }
    }

    // Method used by copyAssets() on purpose to copy a file.
    public static void copyFile(InputStream in, OutputStream out) throws IOException {
        //use of a byte array to store a collection of binary data, for example, the contents of a file
        byte[] buffer = new byte[1024];
        int read;
        while ((read = in.read(buffer)) != -1) {
            out.write(buffer, 0, read);
        }
    }

    public static void closeOnCrashApp(final Activity theActivity) {
        if (AppFolderName.isEmpty() || AlertTitle.isEmpty()
                || PreferenceFileName.isEmpty()) {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(theActivity);
            alertDialogBuilder.setMessage("0000 - Error : Due to unexpected reasons unable to load files," +
                    " Please restart application.");
            alertDialogBuilder.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface arg0, int arg1) {

                            Intent intent = new Intent();
                            intent.putExtra(INTENT_AUTO_CLOSE_APP, true);
                            theActivity.setResult(theActivity.RESULT_OK, intent);
                            theActivity.finish();


                        }
                    });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        }
    }


    public static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // should never happen
            throw new RuntimeException("Could not get package name: " + e);
        }
    }

    public static String getFilenameWithoutExt(String filename) {
        int dotposition = filename.lastIndexOf(".");
        if (dotposition != -1) {
            return filename.substring(0, dotposition);
        } else {
            return filename;
        }
    }

    public static String getExtension(String fileName) {
        String encoded;
        try {
            encoded = URLEncoder.encode(fileName, "UTF-8").replace("+", "%20");
        } catch (UnsupportedEncodingException e) {
            encoded = fileName;
        }
        return MimeTypeMap.getFileExtensionFromUrl(encoded).toLowerCase();
    }

    /*public static void loadImageWithGlide(Context theCtx, ImageView theImageView, String theUrl) {
        //int defaultImagePath = R.drawable.default_thumb;
        Glide.with(theCtx)
                .load(theUrl)
                .apply(new RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .skipMemoryCache(true)
                        .placeholder(defaultImagePath)
                        .fitCenter()).into(theImageView);


    }*/


    /*public static Bitmap generateQrCode(Context theCtx, String theQrCodeString) {
        BitMatrix result;
        int requiredPixel;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) theCtx).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        if (height > width) {
            requiredPixel = width;
        } else {
            requiredPixel = height;
        }

        try {
            result = new MultiFormatWriter().encode(theQrCodeString,
                    BarcodeFormat.QR_CODE, requiredPixel, requiredPixel, null);
        } catch (IllegalArgumentException iae) {
            // Unsupported format
            iae.printStackTrace();
            return null;
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
        int w = result.getWidth();
        int h = result.getHeight();
        int[] pixels = new int[w * h];
        for (int y = 0; y < h; y++) {
            int offset = y * w;
            for (int x = 0; x < w; x++) {
                pixels[offset + x] = result.get(x, y) ? BLACK : WHITE;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, requiredPixel, 0, 0, w, h);
        return bitmap;
    }*/

    public static String computeMD5Hash(String theNormalString) {
        String returnString = "";
        try {
            // Create MD5 Hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(theNormalString.getBytes());
            byte messageDigest[] = digest.digest();

            StringBuffer MD5Hash = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++) {
                String h = Integer.toHexString(0xFF & messageDigest[i]);
                while (h.length() < 2)
                    h = "0" + h;
                MD5Hash.append(h);
            }
            returnString = MD5Hash.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return returnString;
    }

}
